package com.tinet.online;

import com.tinet.oslib.common.PlatformDefine;

/**
 * @author: liuzeren
 * @date: 2022/3/28
 */
public class Constant {

    //Beijing
    public static final long enterpriseId = 8000002;
    public static final String accessId = "8758096679544ff189d4a9457747f109";
    public static final String accessSecret = "72EBF29CB4614F7AB404EEC07BFF0B1B";

    public static final PlatformDefine define = PlatformDefine.Beijing;

}
