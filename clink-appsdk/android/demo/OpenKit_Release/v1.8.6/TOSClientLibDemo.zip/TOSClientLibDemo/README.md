# 开源Kit的Demo项目
## 版本说明
> 由于Kit开源会不定期更新版本，请对接使用时确认使用的版本，以免出现兼容性问题。

## lib层对接文档
> 见doc目录
> Build
> 增加gradle.properties 文件，增加以下内容
org.gradle.jvmargs=-Xmx1536m
android.useAndroidX=true
android.enableJetifier=true
android.injected.testOnly=false
