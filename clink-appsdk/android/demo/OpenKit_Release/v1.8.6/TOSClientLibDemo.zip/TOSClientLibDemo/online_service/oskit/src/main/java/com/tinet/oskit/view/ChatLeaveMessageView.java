package com.tinet.oskit.view;

/**
 * @author: liuzr
 * @date: 2021-12-15
 */
public interface ChatLeaveMessageView extends TinetView {

    /**
     * 留言成功
     */
    void commitSuccess();

}
