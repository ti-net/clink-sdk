package com.tinet.oskit.view;

public interface SatisfactionStatusChange {
    void satisfactionStatus(String mainUniqueId, String uniqueId);
}