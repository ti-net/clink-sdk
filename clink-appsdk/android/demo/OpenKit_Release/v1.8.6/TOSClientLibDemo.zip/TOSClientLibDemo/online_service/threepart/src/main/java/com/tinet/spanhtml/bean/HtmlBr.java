package com.tinet.spanhtml.bean;

import org.jsoup.nodes.Node;

/**
 * @ProjectName: TIMSDK
 * @ClassName: HtmlBr
 * @Author: liuzr
 * @CreateDate: 2021-12-02 18:52
 * @Description: <br/> 换行
 */
public class HtmlBr implements Html {
    @Override
    public void parse(Node node) {

    }
}
