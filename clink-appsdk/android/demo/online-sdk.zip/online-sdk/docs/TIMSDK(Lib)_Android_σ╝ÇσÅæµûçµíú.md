
# TIMSDK(lib)_Android_开发文档

> 版本: 1.2.4.2

# 修订记录

| 版本 | 日期 | 修订人员 | 修订描述 |
| :------ | :------ | :------ | :------ |
| 1.0 | 6/28/2021 | 赵言 | 初始版本 |

## 目录
-  [引入sdk](#import)
-  [初始化](#init)
-  [连接服务](#connect)
-  [设置监听](#listenter)
-  [用户管理](#user)
-  [会话管理](#session)
-  [消息管理](#message)
-  [群组管理](#group)
-  [联系人管理](#contact)
-  [离线推送](#push)

## <span id="import">搭建环境</span>


### 简介
Android TIM Lib SDK  提供完整即时消息场景服务，实现高性能，高可靠的消息服务。

### 环境要求

name | 说明
---|---|---
Android SDK Build-tools | 21 及以上
Android SDK | Android API 19 及以上
JAVA |JDK 1.7 及以上
Gradle | 3.0 及以上版本

### 引入 SDK
#### 一、 Module 方式
导入 Module
1、打开工程， File -> New -> Import Module. 找到下载的 Module 组件导入.
2、在主app的 build.gradle 文件中配置 Module, 如下

```
    implementation project(path: ':timclientlib')
```
添加数据库
2、在项目的 build.gradle 文件中配置如下

① buildscript -> dependencies 节点下：
```
    classpath "io.realm:realm-gradle-plugin:6.0.2"
```

② allprojects -> repositories 节点下：
```
    maven { url "https://jitpack.io" }
```

#### 二、 aar依赖方式
> 说明：使用aar依赖方式不包含离线推送功能，如需使用离线推送功能请使用Module引入SDK

1、下载aar包
2、在主app的 build.gradle 文件中dependencies节点内配置如下
```
    api files('libs/timlib_xxx.xxx.xxx.xxx_sdk_release.aar') //xxx.xxx.xxx.xxx 为最新的版本号
```
### 权限适配
开发者必需动态申请以下权限

```
    Manifest.permission.WRITE_EXTERNAL_STORAGE,
```

##  <span id="init">初始化</span>
### 功能描述
TIMSDK 需要开发者在工程中调用下面方法来初始化 SDK。在 App 的整个生命周期中，开发者只需要将 SDK 初始化一次。

### 参数说明

参数    |	类型    |	必填    |	说明
---     |---        |---        |---
context |	Context |	是 |	上下文对象
tIMInitOption   |	TIMInitOption |是 |	初始化参数option

#### TIMInitOption 参数说明
参数    |	类型    |	必填    |	说明
---     |---        |---        |---
debug |	boolean |	否 |	是否开启debug模式
apiUrl   |	String |	否 |	默认sdk 请求url

### 代码示例
说明：只需要在继承Application类的onCreate初始化一次
```
        /**
         * TIMKit的初始化函数
         *
         * @param context  应用的上下文，一般为对应应用的ApplicationContext
         *
         */
        TIMInitOption initOption = new TIMInitOption();
        initOption.setDebug(false);
        initOption.setApiUrl("您的api服务器地址");
        TIMClient.init(this, initOption);
```

## <span id="connect">连接服务</span>

### 1.连接
说明：
1、调用sdk连接方法前，需要开发者申请appId，并且从自己的服务端获取accessToken，userId，再调用sdk connect方法进行sdk连接；
2、sdk连接方法需要放到MainActivity中，建议在MainActivity开启一个Service，把sdk的连接操作以及初始化监听放入service中

#### 代码示例

```
   /**
     * 建立连接
     *
     * @param
     */
    private void connect() {

        final TIMConnectOption timConnectOption = new TIMConnectOption();

        // : 2020/7/3 此处设置您app的相关参数
        timConnectOption.setAppId("xxx");
        timConnectOption.setAccessToken("xxx");
        timConnectOption.setUserId("xxx");

        TIMClient.connect(timConnectOption, new TConnectResultCallback() {
            @Override
            public void onSuccess(String s) {
                // 连接成功
                // : 2020/7/3 此处开始初始化需要的监听
                initListener();
            }

            @Override
            public void onError(int errorCode, String errorDes) {
               // 连接失败 异常处理
            }
        });
    }

```

### 2.断开连接
说明：
1、退出登录需调用断开连接

#### 代码示例

```
    /**
     *
     * @param isReceivePush 设置是否接收离线push
     */
    TIMClient.disconnect(false);、
```

##  <span id="listenter">事件监听</span>

### 1. 连接状态监听
```
        TIMKit.setTIMConnectStatusListener(new TIMConnectStatusListener() {
            @Override
            public void onConnecting() {
                // : 2020/7/3 连接中监听
            }

            @Override
            public void onConnected() {
                // : 2020/7/3 连接成功
            }

            @Override
            public void onDataSyncing() {
                // : 2020/7/3 数据同步中
            }

            @Override
            public void onDataSynced() {
                // : 2020/7/3 数据同步完成
            }

            @Override
            public void onDisconnected() {
                // : 2020/7/3 断开连接
            }

            @Override
            public void onReConnecting() {
                // : 2020/7/3 重连中
            }

            @Override
            public void onReconnected() {
                // : 2020/7/3 重连成功
            }

            @Override
            public void onKickOut() {
                // : 2020/7/3 处理强制下线操作
            }
        });
```

### 2. 消息接收监听

```
        TIMClient.setTIMReceiveMessageListener(new TIMReceiveMessageListener() {
            @Override
            public void onReceived(TIMMessage timMessage, int leftCount) {
                // : 2020/7/3 收到新消息事件监听
            }
        });
```


##  <span id="user">用户管理</span>
### 1. 获取用户信息

```
        /**
         * 获取用户信息
         *
         * @param targetId
         * @param tResultCallback
         */
        TIMClient.getUserInfo(targetId, new TResultCallback<TIMUser>() {
            @Override
            public void onSuccess(TIMUser data) {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });

```

### 2. 更新用户信息

```
        /**
         * 更新用户信息
         *
         * @param timUser
         */
        TIMKit.updateUserInfo(timUser, new TOperationCallback() {
            @Override
            public void onSuccess() {
                getCurrentUserInfo();
            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });

```
### 3. 上传用户头像

```
        /**
         * 上传用户头像
         *
         * @param path 本地文件路径
         * @param tOperationCallback
         */
        TIMKit.uploadUserAvatar(path, new TOperationCallback() {

            @Override
            public void onSuccess() {
                getCurrentUserInfo();
            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });

```

##  <span id="session">会话管理</span>

### 1. 获取会话列表

```
        //此接口 1.2.3.10(不含)之前的版本最多只能获取3天内的会话列表 1.2.3.10(含)之后的版本可以获取最多1000个会话和3天内的未读数
        TIMSessionListOption timSessionListOption = new TIMSessionListOption();
        timSessionListOption.setStartTime(12345678911L);//时间搓
        timSessionListOption.setLimit(100);//每页加载个数

        TIMClient.getSessionList(timSessionListOption, new TResultCallback<List<TIMSession>>() {
            @Override
            public void onSuccess(List<TIMSession> list) {
               // 获取到会话列表数据
            }

            @Override
            public void onError(int errorCode, String errorDesc) {
                // 获取会话列表失败
            }
        });
```


##  <span id="message">消息管理</span>
### 1. 发送消息

##### TIMMessageSendOption 参数说明
参数    |	类型    |	必填    |	说明
---     |---        |---        |---
targetId |	String |	是 |接收方userId或groupId
content |	TIMMessage |	是 |接收方userId或groupId
pushOption |	TIMPushOption |	否 |可选	需要推送时传入，设备离线时推送

##### TIMPushOption 参数说明
参数    |	类型    |	必填    |	说明
---     |---        |---        |---
pushTitle |	String |	是 |推送标题
pushContent |	String |	是 |推送内容
pushData |	JSONObject |	否 |推送附加配置信息


#### 示例代码
```
        TIMMessageSendOption timMessageSendOption = new TIMMessageSendOption();
        timMessageSendOption.setTargetId(targetId);//单聊或群聊id
        timMessageSendOption.setContent(timMessage);//消息对象，详见发送消息对象构造
        TIMClient.sendMessage(timMessageSendOption, new TSendMessageCallback() {
            @Override
            public void onProgress(TIMMessage timMessage, int progress) {
                //发送进度，文本消息忽略此方法回调
            }

            @Override
            public void onSuccess(TIMMessage timMessage) {
               //发送成功回调
            }

            @Override
            public void onError(TIMMessage timMessage, int errorCode, String errorDesc) {
               //发送失败回调
            }
        });
```
#### timMessage 发送消息对象构造
> ##### 文本消息

```
        TextMessage textMessage = TextMessage.obtain("发送的文本内容");
        TIMMessage timMessage = TIMMessage.obgain(mSessionType, textMessage);
```

> ##### 图片消息

```
        ImageMessage imageMessage = ImageMessage.obtain("图片文件Uri", false);
        TIMMessage timMessage = TIMMessage.obgain(mSessionType, imageMessage);
```

> ##### 语音消息

```
        VoiceMessage voiceMessage = VoiceMessage.obtain("音频文件Uri");
        TIMMessage timMessage = TIMMessage.obgain(mSessionType, voiceMessage);
```

> ##### 视频消息

```
        VideoMessage videoMessage = VideoMessage.obtain("视频文件Uri");//targetSdkVersion >= 30，视频文件Uri路劲必须在应用包名下
        TIMMessage timMessage = TIMMessage.obgain(mSessionType, videoMessage);
```

> ##### 语音消息

```
        VoiceMessage videoMessage = VoiceMessage.obtain("音频文件Uri");
        TIMMessage timMessage = TIMMessage.obgain(mSessionType, videoMessage);
```

> ##### 自定义文件消息

```
        TIMMessageSendOption timMessageSendOption = new TIMMessageSendOption();
        Map<String, Object> bodyMap = new HashMap<>();
        bodyMap.put("fileTypeDesc", "车辆健康检查报告");
        bodyMap.put("fileType", fileType);
        bodyMap.put("fileName", "VCIC_IM_001."+fileType);
        bodyMap.put("createTime", "2021-03-04");

        String customizeMessageExtra = "";
        CustomizeMessage customizeMessage = CustomizeMessage.obtain(TLibCommonConstants.CUSTOMIZE_MSG_TYPE_BMW_REPORT_FILE, bodyMap, customizeMessageExtra);
        TIMMessage timMessage = TIMMessage.obgain(mSessionType, customizeMessage);
```

++**备注：以上消息类型，含Uri的仅支持本地文件Uri**++


##### TIMMessage 回调参数说明
字段                 |	类型                |	说明
---                  | ---                 | ---
msgId                |	String              |	消息唯一ID(发送成功后存在)
type                 |	String              |	消息类型
content              |	TIMMesageContent    |	消息内容抽象对象
senderId             |	String              |	发送者ID
receiverId           |	String              |	发送者ID
msgFrom              |	int                 |	消息归属（1 个人消息，2 群消息）
status               |	int                 |	消息状态 * -1 发送失败 * 0 发送中 * 1 已发送 * 2 未读 * 3 已读
sendTime             |	Long                |	发送时间
messageDirection     |	int         |	消息方向，1发送方  2接收方

### 2. 获取历史消息


```
        TIMMessageHistoryOption messageHistoryOption = new TIMMessageHistoryOption();
        messageHistoryOption.setTargetId(mTargetId);//群聊id或单聊用户id
        messageHistoryOption.setMessageId(lastMessageId);//最后条消息id
        messageHistoryOption.setLimit(20);//查询条数
        messageHistoryOption.setType(TMessageType.IMAGE);;//查询消息类型

        TIMClient.getMessageHistory(messageHistoryOption, new TMessageHistoryCallback() {
            @Override
            public void onSuccess(final List<TIMMessage> data) {
               //获取成功
            }

            @Override
            public void onError(int errorCode, String errorDesc) {
               //获取失败
            }
        });
```
### 3. 发送消息已读回执

```
            // : 2020/7/3 发送消息已读回执
            TIMMessageReadOption timMessageReadOption = new TIMMessageReadOption();
            timMessageReadOption.setSenderId("xxx");
            timMessageReadOption.setTargetId("xxx");
            timMessageReadOption.setMessageIds(new String[]{"xxx"});
            timMessageReadOption.setSessionType("xxx");
            timMessageReadOption.setLatestMessageId("xxx");
            TIMKit.sendMessageRead(timMessageReadOption, new TOperationCallback() {
                @Override
                public void onSuccess() {
                    TLogUtils.i("sendMessageRead onSuccess");
                }

                @Override
                public void onError(int errorCode, String errorDesc) {
                    TLogUtils.i("sendMessageRead onError:" + errorDesc);
                }
            });
```
### 4. 更新文件相关消息Uri

```
    /**
     *
     * @param uri 需要更新的Uri
     * @return 更新后的Uri
     */
    TIMClient.updateFileUri(uri);

```
### 5. 消息撤回

```
TIMClient.recallMessage("消息id", "会话id", new TOperationCallback() {
            @Override
            public void onSuccess() {
                // : 2020/11/6 撤回成功
            }

            @Override
            public void onError(int errorCode, String errorDesc) {
                // : 2020/11/6 撤回失败
            }
        });

```

### 6. 自定义消息

```
  // : 2021/4/16 定义 tim-bmwReportFile 模板自定义消息
        TIMMessageSendOption timMessageSendOption = new TIMMessageSendOption();
        Map<String, Object> bodyMap = new HashMap<>();
        bodyMap.put("fileTypeDesc", "车辆健康检查报告");
        bodyMap.put("fileType", fileType);
        bodyMap.put("fileName", "VCIC_IM_001."+fileType);
        bodyMap.put("createTime", "2021-03-04");
        String customizeMessageExtra = "";
        CustomizeMessage customizeMessage = CustomizeMessage.obtain(TLibCommonConstants.CUSTOMIZE_MSG_TYPE_BMW_REPORT_FILE, bodyMap, customizeMessageExtra);
        TIMMessage timMessage = TIMMessage.obgain(mSessionType, customizeMessage);

```

##  <span id="group">群组管理</span>
### 1. 创建群组

```
        TIMGroupOption timGroupOption = new TIMGroupOption();
        timGroupOption.setName("群名称");
        timGroupOption.setDescription("群备注说明");
        timGroupOption.setMembers(members);//群成员id数组
        TIMKit.createGroup(timGroupOption, new TResultCallback<TIMGroup>() {
            @Override
            public void onSuccess(TIMGroup data) {
                //创建成功
            }

            @Override
            public void onError(int errorCode, String errorDesc) {
                //创建失败
            }
        });
```

### 2. 删除群组
```
        /**
         * 邀请进群
         *
         * @param targetId            群组id
         */
        TIMClient.deleteGroup(targetId, new TOperationCallback() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });
```
### 3. 更新群组信息

```
        TIMGroupOption timGroupOption = new TIMGroupOption();
        timGroupOption.setName("群名称");
        timGroupOption.setDescription("群备注说明");
        TIMKit.updateGroup(timGroupOption, new TResultCallback<TIMGroup>() {
            @Override
            public void onSuccess(TIMGroup data) {
                //更新成功
            }

            @Override
            public void onError(int errorCode, String errorDesc) {
                //更新失败
            }
        });
```
### 4. 获取群组信息

```
        /**
         * 获取群组信息
         *
         * @param targetId            群组id
         */
        TIMKit.getGroupInfo(targetId, new TResultCallback<TIMGroup>() {
            @Override
            public void onSuccess(TIMGroup data) {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });
```

### 5. 获取群组列表

```
        TIMKit.getGroupList(new TResultCallback<List<TIMGroup>>() {
            @Override
            public void onSuccess(List<TIMGroup> list) {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });

```

### 6. 获取群组成员列表
```
        // :  请求群组成员信息接口
        TIMClient.getGroupMemberList(mTargetId, new TResultCallback<List<TIMGroupMember>>() {
            @Override
            public void onSuccess(List<TIMGroupMember> list) {
                //操作成功，返回群组成员列表
            }

            @Override
            public void onError(int errorCode, String errorDesc) {
                //操作失败
            }
        });
```
### 6. 主动加群

```
        TIMJoinGroupOption timJoinGroupOption = new TIMJoinGroupOption();
        timJoinGroupOption.setType(1);
        timJoinGroupOption.setGroupId("群组id");
        timJoinGroupOption.setDescription("主动加群");
        TIMClient.joinGroup(timJoinGroupOption, new TOperationCallback() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });
```

### 7. 邀请进群

```
        /**
         * 邀请进群
         *
         * @param mTargetId            群组id
         * @param members            邀请用户的id数组
         * @param tOperationCallback 回调监听
         */
        TIMClient.inviteUserToGroup(mTargetId, members, new TOperationCallback() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });

```

### 9. 主动退出群聊

```
        /**
         * 邀请进群
         *
         * @param targetId            群组id
         */
        TIMClient.quiteGroup(targetId, new TOperationCallback() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });
```

##  <span id="contact">联系人管理</span>
### 1. 添加联系人

```
        TIMContactOption timContactOption = new TIMContactOption();
        timContactOption.setContactUserId("要添加的联系人用户id");
        timContactOption.setAlias("设置昵称");
        TIMClient.addContact(timContactOption, new TResultCallback<TIMContact>() {
            @Override
            public void onSuccess(TIMContact data) {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });
```

### 2. 删除联系人

```
        /**
         * 删除联系人
         *
         * @param targetId            联系人id
         */
        TIMClient.deleteContact(targetId, new TOperationCallback() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });
```

### 3. 更新联系人

```
        TIMContactOption timContactOption = new TIMContactOption();
        timContactOption.setContactUserId("要更新的联系人用户id");
        timContactOption.setAlias("更新后昵称");
        TIMClient.updateContact(timContactOption, new TResultCallback<TIMContact>() {
            @Override
            public void onSuccess(TIMContact data) {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });
```

### 4. 获取联系人

```
        /**
         * 获取联系人
         *
         * @param targetId            联系人id
         */
        TIMClient.getContact(targetId, new TResultCallback<TIMContact>() {
            @Override
            public void onSuccess(TIMContact data) {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });
```

### 5. 获取联系人列表

```
        TIMContactListOption timContactListOption = new TIMContactListOption();
        timContactListOption.setStart(0);//设置要获取的起始页
        timContactListOption.setLimit(50);//设置每页查询的数量
        TIMClient.getContactList(timContactListOption, new TResultCallback<List<TIMContact>>() {
            @Override
            public void onSuccess(List<TIMContact> data) {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });
```


## <span id="push">离线推送</span>

 #### 1. 账号配置

```
        PushConfig config = new PushConfig.Builder()
                .setMiPush(ConfigConstant.XIAOMI_APP_ID, ConfigConstant.XIAOMI_APP_key)
                .setHWPush(true)
                .setOppoPush(ConfigConstant.OPPO_APP_key, ConfigConstant.OPPO_APP_SECRET)
                .setVivoPush(true)
                .setMeiZuPush(ConfigConstant.MEIZU_APP_ID, ConfigConstant.MEIZU_APP_key)
                .build();
        TIMPushManager.setPushConfig(config);
```
**说明：以上配置需放置在继承Application类中，且在init()方法之前调用**

 #### 2. AndroidManifest.xml文件权限配置

```

    <!-- ========================== 小米 push 相关配置  开始======================== -->
    <permission
        android:name="${applicationId}.permission.MIPUSH_RECEIVE"
        android:protectionLevel="signature" />
    <uses-permission android:name="${applicationId}.permission.MIPUSH_RECEIVE" />
    <!-- ========================== 小米 push 相关配置  结束======================== -->

    <!-- ========================== 华为 push 相关配置  开始======================== -->
    <!-- 接收PUSH TOKEN的广播以及PUSH消息需要定义该权限 com.tinet.timsdk 要替换上您应用的包名 -->
    <permission
        android:name="${applicationId}.permission.PROCESS_PUSH_MSG"
        android:protectionLevel="signatureOrSystem"/>

    <!--接收PUSH TOKEN的广播以及PUSH消息需要定义该权限 com.tinet.timsdk 要替换上您应用的包名 -->
    <uses-permission android:name="${applicationId}.permission.PROCESS_PUSH_MSG" />
    <!-- ========================== 华为 push 相关配置  结束======================== -->

    <!-- ========================== 魅族 push 相关配置  开始======================== -->
    <!-- 兼容 flyme5.0 以下版本，魅族内部集成 pushSDK 必填，不然无法收到消息-->
    <uses-permission android:name="com.meizu.flyme.push.permission.RECEIVE"/>
    <permission android:name="${applicationId}.push.permission.MESSAGE"
        android:protectionLevel="signature"/>
    <uses-permission android:name="${applicationId}.push.permission.MESSAGE"/>
    <!-- 兼容 flyme3.0 配置权限-->
    <uses-permission android:name="com.meizu.c2dm.permission.RECEIVE"
        />
    <permission android:name="${applicationId}.permission.C2D_MESSAGE"
        android:protectionLevel="signature"/>
    <uses-permission android:name="${applicationId}.permission.C2D_MESSAGE"/>
    <!-- ========================== 魅族 push 相关配置  结束======================== -->

```
**说明：以上applicationId为您应用的package**

 #### 3. AndroidManifest.xml文件其他配置

```
        <!-- ========================== 华为 push 相关配置  开始======================== -->
        <!--   华为账号appid     -->
        <meta-data
            android:name="com.huawei.hms.client.appid"
            android:value="xxx" />

        <!-- 接入HMSSDK 需要注册的provider，authorities 一定不能与其他应用一样，所以这边 ${applicationId}要替换上您应用的包名-->
        <provider
            android:name="com.huawei.hms.update.provider.UpdateProvider"
            android:authorities="${applicationId}.hms.update.provider"
            android:exported="false"
            android:grantUriPermissions="true" />

        <!-- 接入HMSSDK 需要注册的provider，authorities 一定不能与其他应用一样，所以这边 ${applicationId} 要替换上您应用的包名-->
        <provider
            android:name="com.huawei.updatesdk.fileprovider.UpdateSdkFileProvider"
            android:authorities="${applicationId}.updateSdk.fileProvider"
            android:exported="false"
            android:grantUriPermissions="true"></provider>

        <!-- 接入HMSSDK PUSH模块需要注册，第三方相关 :接收Push消息（注册、透传消息、通知栏点击事件）广播，
                此receiver类需要开发者自己创建并继承com.huawei.hms.support.api.push.PushReceiver类，
                参考示例代码中的类：com.huawei.hmsagent.HuaweiPushRevicer ${applicationId} 要替换上您应用的包名-->
        <receiver
            android:name="com.tinet.push.platform.huawei.HMSReceiver"
            android:permission="${applicationId}.permission.PROCESS_PUSH_MSG">
            <intent-filter>
                <!-- 必须,用于接收token -->
                <action android:name="com.huawei.android.push.intent.REGISTRATION" />
                <!-- 必须, 用于接收透传消息 -->
                <action android:name="com.huawei.android.push.intent.RECEIVE" />
                <!-- 必须, 用于接收通知栏消息点击事件 此事件不需要开发者处理，只需注册就可以-->
                <action android:name="com.huawei.intent.action.PUSH_DELAY_NOTIFY" />
            </intent-filter>
        </receiver>
        <!-- ========================== 华为 push 相关配置  结束======================== -->

        <!-- ========================== vivo push 相关配置  开始======================== -->
        <!--Vivo Push开放平台中应用的appid 和api key-->
        <meta-data
            android:name="com.vivo.push.api_key"
            android:value="xxx" />
        <meta-data
            android:name="com.vivo.push.app_id"
            android:value="xxx" />
        <!-- ========================== vivo push 相关配置  结束======================== -->

        <!--  ========================== meizu push 相关配置  开始======================= -->
        <!-- push 应用定义消息 receiver 声明 -->
        <receiver android:name="com.tinet.push.platform.meizu.MZReceiver">
            <intent-filter>
                <!-- 接收 push 消息 -->
                <action android:name="com.meizu.flyme.push.intent.MESSAGE" />
                <!-- 接收 register 消息 -->
                <action android:name="com.meizu.flyme.push.intent.REGISTER.FEEDBACK" />
                <!-- 接收 unregister 消息-->
                <action android:name="com.meizu.flyme.push.intent.UNREGISTER.FEEDBACK" />
                <!-- 兼容低版本 Flyme3 推送服务配置 -->
                <action android:name="com.meizu.c2dm.intent.REGISTRATION" />
                <action android:name="com.meizu.c2dm.intent.RECEIVE" />

                <category android:name="${applicationId}" />
            </intent-filter>
        </receiver>
        <!-- ========================== meizu push 相关配置  结束======================== -->


```
**说明：以上配置需要在application标签内,且需要替换xxx为您应用对应的appid或appkey**
