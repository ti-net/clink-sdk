
# TIMSDK(kit)_Android_开发文档

> *版本: 1.2.4.2

# 修订记录

| 版本 | 日期 | 修订人员 | 修订描述 |
| :------ | :------ | :------ | :------ |
| 1.0 | 6/28/2021 | 赵言 | 初始版本 |

## 目录
-  [引入sdk](#import)
-  [初始化](#init)
-  [连接服务](#connect)
-  [设置监听](#listenter)
-  [会话界面](#session)
-  [会话列表](#sessionList)
-  [群组管理](#group)
-  [离线推送](#push)

### 简介
Android TIMSDK 提供完整会话列表，会话即时消息场景服务，实现高性能，高可靠的消息服务。

### 环境要求

name | 说明
---|---
Android SDK Build-tools | 21 及以上
Android SDK | Android API 19 及以上
JAVA |JDK 1.7 及以上
Gradle | 3.0 及以上版本

## <span id="import">引入 SDK</span>
#### Module 方式
导入 Module
1、打开工程， File -> New -> Import Module. 找到下载的 Module 组件导入.
2、在主app的 build.gradle 文件中配置 Module, 如下

```
implementation project(path: ':timkitlib')
```
添加数据库
2、在项目的 build.gradle 文件中配置如下

① buildscript -> dependencies 节点下：
```
classpath "io.realm:realm-gradle-plugin:6.0.2"
```

② allprojects -> repositories 节点下：
```
maven { url "https://jitpack.io" }
```
### 权限适配
注：开发者需要动态申请以下权限

```
Manifest.permission.WRITE_EXTERNAL_STORAGE
```
### 依赖库版本适配
- 说明：部分用户与sdk依赖了同样的第三方库，但是版本不一致造成应用无法正常运行
- 解决方案：可直接在依赖model中的build.gradle文件夹下做升降级配置已解决版本统一问题

### Android Q 适配
- 背景 ：Android Q文件存储机制修改成了沙盒模式
- 说明 ：IM SDK 内部读写存储操作已做了 tAndroid Q 读写存储的适配操作
- 解决方案：  
1 、必须在app下build.gradle文件中设置targetSdkVersion >= 29  
2、必须在AndroidManifest.xml的application标签下声明**requestLegacyExternalStorage=true**，才可以访问沙盒路径下的数据


### 多设备登录注意事项
- 说明：目前IM系统只支持单设备登录，如收到被踢下线通知(参考setTIMConnectStatusListener中onKickOut)需要用户做退出登录操作，并调用sdk 的TIMKit.disconnect(false)断开连接跳转至app登录页面

##  <span id="init">初始化</span>
### 功能描述
TIMSDK 需要开发者在工程中调用下面方法来初始化 SDK。在 App 的整个生命周期中，开发者只需要将 SDK 初始化一次。

### 参数说明

参数    |	类型    |	必填    |	说明
---     |---        |---        |---
context |	Context |	是 |	上下文对象
tIMInitOption   |	TIMInitOption |是 |	初始化参数option

#### TIMInitOption 参数说明
参数    |	类型    |	必填    |	说明
---     |---        |---        |---
debug |	boolean |	否 |	是否开启debug模式
apiUrl   |	String |	否 |	默认sdk 请求url


### 代码示例
说明：只需要在继承Application类的onCreate初始化一次
```

        /**
         * 配置附加面板item
         * 注：type字段需定义在（1，2，3，4）之外，type主要用于回调判断点击条目
         */
        List<TIMExtraSpanBean> mTIMExtraSpanBeans = new ArrayList<>();
        mTIMExtraSpanBeans.add(new TIMExtraSpanBean(5, com.tinet.timkit.R.drawable.ti_ic_coupon_span, "优惠券"));
        mTIMExtraSpanBeans.add(new TIMExtraSpanBean(6, com.tinet.timkit.R.drawable.ti_ic_form_span, "表单"));
        mTIMExtraSpanBeans.add(new TIMExtraSpanBean(7, com.tinet.timkit.R.drawable.ti_ic_goods_span, "商品"));
        mTIMExtraSpanBeans.add(new TIMExtraSpanBean(8, com.tinet.timkit.R.drawable.ti_ic_book_span, "企业宣传册"));
        mTIMExtraSpanBeans.add(new TIMExtraSpanBean(9, "文件入口图标", "文件"));

        /**
         * 获取默认常用语内容(可自定义)
         *
         */
        String[] commonWords = getResources().getStringArray(R.array.ti_chat_normal_content);
        List<String> sessionCommonWords = Arrays.asList(commonWords);

        /**
         * 启用配置项
         *
         */
        TIMKitConfig timKitConfig = new TIMKitConfig.Builder()
                .addExtraSpanList(mTIMExtraSpanBeans)
                .setSessionCommonWordsList(sessionCommonWords)
                .setShowReConnectPopDialog(false)
                .build();
        TIMKitManager.setTimKitConfig(timKitConfig);


        /**
         * TIMKit的初始化函数
         *
         * @param context  应用的上下文，一般为对应应用的ApplicationContext
         *
         */
        TIMInitOption initOption = new TIMInitOption();
        initOption.setDebug(false);
        initOption.setApiUrl("您开通的服务器地址");
        TIMKit.init(this, initOption);
```

## <span id="connect">连接服务</span>
说明：
1、调用sdk连接方法前，需要开发者申请appId，并且从自己的服务端获取accessToken，userId，再调用sdk connect方法进行sdk连接；
2、sdk连接方法需要放到MainActivity中，建议在MainActivity开启一个Service，把sdk的连接操作以及初始化监听放入service中

### 代码示例

```
   /**
     * 建立连接
     *
     * @param
     */
    private void connect() {

        final TIMConnectOption timConnectOption = new TIMConnectOption();

        // : 2020/7/3 此处设置您app的相关参数
        timConnectOption.setAppId("xxx");
        timConnectOption.setAccessToken("xxx");
        timConnectOption.setUserId("xxx");

        TIMKit.connect(timConnectOption, new TConnectResultCallback() {
            @Override
            public void onSuccess(String s) {
                // 连接成功
            }

            @Override
            public void onError(int errorCode, String errorDes) {
               // 连接失败
            }
        });
    }

     /**
     * 断开连接
     *
     * @param 是否接受离线push（该功能只有在启用了离线push下才生效）
     */
    TIMKit.disconnect(false);

```

##  <span id="listenter">事件监听</span>


### 1. 连接状态监听

```
TIMKit.setTIMConnectStatusListener(new TIMConnectStatusListener() {
            @Override
            public void onConnecting() {
                // : 2020/7/3 连接中监听
            }

            @Override
            public void onConnected() {
                // : 2020/7/3 连接成功
            }

            @Override
            public void onDataSyncing() {
                // : 2020/7/3 消息数据同步中
            }

            @Override
            public void onDataSynced() {
                // : 2020/7/3 数据同步完成
            }

            @Override
            public void onDisconnected() {
                // : 2020/7/3 断开连接
            }

            @Override
            public void onReConnecting() {
                // : 2020/7/3 重连中
            }

            @Override
            public void onReconnected() {
                // : 2020/7/3 重连成功
            }

            @Override
            public void onKickOut() {
                // : 2020/7/3 处理强制下线操作
            }
        });
```

### 2. 消息接收监听

```
        TIMKit.setTIMReceiveMessageListener(new TIMReceiveMessageListener() {
            @Override
            public void onReceived(TIMMessage timMessage, int leftCount) {
                // : 2020/7/3 收到新消息事件监听
            }
        });
```

### 3. 总未读数变化监听

```
        TIMKit.setTIMTotalUnreadCountChangedListener(new TIMTotalUnreadCountChangedListener() {
            /**
             * @param unreadCount 当前最新总未读数
             */
            @Override
            public void onChangedListener(int unreadCount) {

            }
        });

```

### 4. 获取总未读消息数

```
        int timTotalUnreadCount = TIMKit.getTIMTotalUnreadCount();
```
### 5. 审核消息发送成功回调监听

```
        TIMKit.setTIMAuditMessageSuccessListener(new TIMAuditMessageSuccessListener() {
            @Override
            public void onSuccess(String groupId) {
                //发送成功，回调groupId
            }
        });```
```


##  <span id="session">会话界面</span>
说明：TIMKit 已经实现了一个默认的会话视图界面，直接使用此类，即可快速启动和使用会话列表界面。
### 构建会话
1. 创建会话 SessionActivity 以及 Activity 所对应的 xml 布局 activity_Session.xml.（也可直接走后面的步骤引入现有的Activity界面）
2. activity_Session.xml 布局中创建 View 容器, 用于动态添加 TSessionFragment.如下代码：

```
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".SessionActivity">

    <FrameLayout
        android:id="@+id/tim_session_fr"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

</LinearLayout>
```
3. 在 SessionActivity 的 onCreate 方法中创建并使用 TSessionFragment.如下代码：

```
        mTargetId = getIntent().getStringExtra("targetId"); //需要进入会话的targetId
        mSessionType = getIntent().getIntExtra("callSessionType", TSessionType.PRIVATE); //需要进入的会话类型
        try {
            // :  加载聊天会话Fragment
            TSessionFragment mConversationFragment = new TSessionFragment(SessionActivity.this, mTargetId, mSessionType);
            FragmentManager manager = getSupportFragmentManager();
            FragmentTransaction transaction = manager.beginTransaction();
            transaction.replace(R.id.tim_session_fr, mConversationFragment);
            transaction.commit();
        } catch (Exception e) {
            //异常处理
        }
```
### 会话界面相关监听
#### 1. 扩展面板item点击事件监听

```
    mConversationFragment.setTIMSessionExtraClickListener(new TIMSessionExtraClickListener() {
                @Override
                public void onItemClick(int position, TIMExtraSpanBean timExtraSpanBean) {
                    if(timExtraSpanBean.getType() == 5){
                        sendCustomerMessage();
                    }
                }
            });
```

#### 2. 发送自定义消息

```
        // : 2020/8/28 定义 defalut 模板自定义消息
        TIMMessageSendOption timMessageSendOption = new TIMMessageSendOption();
        Map<String, Object> bodyMap = new HashMap<>();
        bodyMap.put("imgUrl", "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1598538013845&di=5a3beaebec92790460866392660d771f&imgtype=0&src=http%3A%2F%2Fpic76.nipic.com%2Ffile%2F20150828%2F20512789_152524036000_2.png");
        bodyMap.put("shareTitle", "来自：马俊");
        bodyMap.put("title", "全新宝马BMW X5");
        bodyMap.put("content", "全场<span style=\"font-size:24px\"><span style=\"color:#e74c3c\">99</span></span><span style=\"color:#e74c3c\">元</span>起");
        String customizeMessageExtra = "";
        CustomizeMessage customizeMessage = CustomizeMessage.obtain(TLibCommonConstants.CUSTOMIZE_MSG_TYPE_DEFAULT, bodyMap, customizeMessageExtra);
        TIMMessage timMessage = TIMMessage.obgain(mSessionType, customizeMessage);

        // : 2021/4/16 定义 tim-bmwReportFile 模板自定义消息
        TIMMessageSendOption timMessageSendOption = new TIMMessageSendOption();
        Map<String, Object> bodyMap = new HashMap<>();
        bodyMap.put("fileTypeDesc", "车辆健康检查报告");
        bodyMap.put("fileType", fileType);
        bodyMap.put("fileName", "VCIC_IM_001."+fileType);
        bodyMap.put("createTime", "2021-03-04");
        String customizeMessageExtra = "";
        CustomizeMessage customizeMessage = CustomizeMessage.obtain(TLibCommonConstants.CUSTOMIZE_MSG_TYPE_BMW_REPORT_FILE, bodyMap, customizeMessageExtra);
        TIMMessage timMessage = TIMMessage.obgain(mSessionType, customizeMessage);

        // : 2021/4/16 发送自定义消息
        timMessageSendOption.setTargetId(mTargetId);
        timMessageSendOption.setContent(timMessage);
        mConversationFragment.sendCustomerMessage(timMessageSendOption, new TSendMessageCallback() {
            @Override
            public void onProgress(TIMMessage timMessage, int progress) {
                TLogUtils.i("app 发送自定义消息 onProgress：" + progress);
            }

            @Override
            public void onSuccess(TIMMessage timMessage) {
                TLogUtils.i("app 发送自定义消息成功");
            }

            @Override
            public void onError(TIMMessage timMessage, int errorCode, String errorDesc) {
                TLogUtils.e("app 发送自定义消息失败：" + errorDesc);
            }
        });
```

#### 3. 会话界面自定义消息点击事件监听

```
        mConversationFragment.setTIMSessionCustomMessageItemListener(new TIMSessionCustomMessageItemListener() {
            @Override
            public void onItemClick(TIMMessage timMessage, View itemView, int position) {

            }
        });
```

## <span id="sessionList">会话列表</span>
说明：TIMKit 已经实现了一个默认的会话视图界面，直接使用此类，即可快速启动和使用会话列表界面。
### 构建会话列表
1. 创建会话列表 SessionListActivity 以及 Activity 所对应的 xml 布局 activity_Session_list.xml.（也可直接走后面的步骤引入现有的Activity或fragment界面）
2. activity_Session_list.xml 布局中创建 View 容器, 用于动态添加 TSessionListFragment.如下代码：
```
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".SessionActivity">

    <FrameLayout
        android:id="@+id/tim_session_list_fr"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

</LinearLayout>
```
3. 在 SessionActivity 的 onCreate 方法中创建并使用 TSessionFragment.如下代码：

```
        try {
            // :  加载会话列表Fragment
            TSessionListFragment mConversationFragment = new TSessionListFragment(MainActivity.this);
            FragmentManager manager = getSupportFragmentManager();
            FragmentTransaction transaction = manager.beginTransaction();
            transaction.replace(R.id.tim_session_list_fr, mConversationFragment);
            transaction.commit();
        } catch (Exception e) {
            // 异常处理
        }
```
### 会话列表相关监听

```
        tSessionListFragment.setSessionListEventListener(new TIMSessionListEventListener() {
            @Override
            public boolean onSessionPortraitClick(Context context, int callSessionType, String targetId) {
                //会话列表头像点击事件
                return false;
            }

            @Override
            public boolean onSessionPortraitLongClick(Context context, int callSessionType, String targetId) {
                //会话列表头像长按事件
                return false;
            }

            @Override
            public boolean onSessionLongClick(Context context, View var2, TIMSession timSession) {
                //会话列表item长按回调事件
                return false;
            }

            @Override
            public boolean onSessionClick(Context context, View var2, TIMSession timSession) {
                //此处为会话列表item点击事件，可进行点击会话进入会话详情操作
                return false;
            }
        });
```

## <span id="group">群组管理</span>

 ### 创建群组

```
        TIMGroupOption timGroupOption = new TIMGroupOption();
        timGroupOption.setName("群名称");
        timGroupOption.setDescription("群说明");
        //群组成员id数组
        timGroupOption.setMembers(members);
        TIMKit.createGroup(timGroupOption, new TResultCallback<TIMGroup>() {
            @Override
            public void onSuccess(TIMGroup data) {

            }

            @Override
            public void onError(int errorCode, String errorDesc) {

            }
        });
```

 ### 主动加群

```
           TIMJoinGroupOption timJoinGroupOption = new TIMJoinGroupOption();
           timJoinGroupOption.setType(1); //类型，管理员或非管理员，自己定义
           timJoinGroupOption.setGroupId(groupId);//群id
           timJoinGroupOption.setDescription("主动加群");//描述
           TIMKit.joinGroup(timJoinGroupOption, new TOperationCallback() {
               @Override
               public void onSuccess() {
                   //主动申请成功
               }
               @Override
               public void onError(int errorCode, String errorDesc) {
                    //主动申请失败
               }
           });
```


 ### 邀请用户进群

```
           * @param mTargetId 群id
           * @param members 邀请用户的id数组
           * @param tOperationCallback 回调监听
           TIMKit.inviteUserToGroup(mTargetId, members, new TOperationCallback() {
               @Override
               public void onSuccess() {
                   //邀请成功
               }
               @Override
               public void onError(int errorCode, String errorDesc) {
                   //邀请失败
               }
           });
```

 ### 退出群聊

```
           * @param mTargetId 群id
           * @param tOperationCallback 回调监听
            TIMKit.quiteGroup(mTargetId, new TOperationCallback() {
                @Override
                public void onSuccess() {
                    //退出成功
                }

                @Override
                public void onError(int errorCode, String errorDesc) {
                    //退出失败
                }
            });
```

## <span id="push">离线推送</span>

 ### push配置

 #### 1. 账号配置

```
        PushConfig config = new PushConfig.Builder()
                .setMiPush(ConfigConstant.XIAOMI_APP_ID, ConfigConstant.XIAOMI_APP_key)
                .setHWPush(true)
                .setOppoPush(ConfigConstant.OPPO_APP_key, ConfigConstant.OPPO_APP_SECRET)
                .setVivoPush(true)
                .setMeiZuPush(ConfigConstant.MEIZU_APP_ID, ConfigConstant.MEIZU_APP_key)
                .build();
        TIMPushManager.setPushConfig(config);
```
**说明：以上配置需放置在继承Application类中，且在init()方法之前调用**

 #### 2. AndroidManifest.xml文件权限配置

```

    <!-- ========================== 小米 push 相关配置  开始======================== -->
    <permission
        android:name="${applicationId}.permission.MIPUSH_RECEIVE"
        android:protectionLevel="signature" />
    <uses-permission android:name="${applicationId}.permission.MIPUSH_RECEIVE" />
    <!-- ========================== 小米 push 相关配置  结束======================== -->

    <!-- ========================== 华为 push 相关配置  开始======================== -->
    <!-- 接收PUSH TOKEN的广播以及PUSH消息需要定义该权限 com.tinet.timsdk 要替换上您应用的包名 -->
    <permission
        android:name="${applicationId}.permission.PROCESS_PUSH_MSG"
        android:protectionLevel="signatureOrSystem"/>

    <!--接收PUSH TOKEN的广播以及PUSH消息需要定义该权限 com.tinet.timsdk 要替换上您应用的包名 -->
    <uses-permission android:name="${applicationId}.permission.PROCESS_PUSH_MSG" />
    <!-- ========================== 华为 push 相关配置  结束======================== -->

    <!-- ========================== 魅族 push 相关配置  开始======================== -->
    <!-- 兼容 flyme5.0 以下版本，魅族内部集成 pushSDK 必填，不然无法收到消息-->
    <uses-permission android:name="com.meizu.flyme.push.permission.RECEIVE"/>
    <permission android:name="${applicationId}.push.permission.MESSAGE"
        android:protectionLevel="signature"/>
    <uses-permission android:name="${applicationId}.push.permission.MESSAGE"/>
    <!-- 兼容 flyme3.0 配置权限-->
    <uses-permission android:name="com.meizu.c2dm.permission.RECEIVE"
        />
    <permission android:name="${applicationId}.permission.C2D_MESSAGE"
        android:protectionLevel="signature"/>
    <uses-permission android:name="${applicationId}.permission.C2D_MESSAGE"/>
    <!-- ========================== 魅族 push 相关配置  结束======================== -->

```
**说明：以上applicationId为您应用的package**

 #### 3. AndroidManifest.xml文件其他配置

```
        <!-- ========================== 华为 push 相关配置  开始======================== -->
        <!--   华为账号appid     -->
        <meta-data
            android:name="com.huawei.hms.client.appid"
            android:value="xxx" />

        <!-- 接入HMSSDK 需要注册的provider，authorities 一定不能与其他应用一样，所以这边 ${applicationId}要替换上您应用的包名-->
        <provider
            android:name="com.huawei.hms.update.provider.UpdateProvider"
            android:authorities="${applicationId}.hms.update.provider"
            android:exported="false"
            android:grantUriPermissions="true" />

        <!-- 接入HMSSDK 需要注册的provider，authorities 一定不能与其他应用一样，所以这边 ${applicationId} 要替换上您应用的包名-->
        <provider
            android:name="com.huawei.updatesdk.fileprovider.UpdateSdkFileProvider"
            android:authorities="${applicationId}.updateSdk.fileProvider"
            android:exported="false"
            android:grantUriPermissions="true"></provider>

        <!-- 接入HMSSDK PUSH模块需要注册，第三方相关 :接收Push消息（注册、透传消息、通知栏点击事件）广播，
                此receiver类需要开发者自己创建并继承com.huawei.hms.support.api.push.PushReceiver类，
                参考示例代码中的类：com.huawei.hmsagent.HuaweiPushRevicer ${applicationId} 要替换上您应用的包名-->
        <receiver
            android:name="com.tinet.push.platform.huawei.HMSReceiver"
            android:permission="${applicationId}.permission.PROCESS_PUSH_MSG">
            <intent-filter>
                <!-- 必须,用于接收token -->
                <action android:name="com.huawei.android.push.intent.REGISTRATION" />
                <!-- 必须, 用于接收透传消息 -->
                <action android:name="com.huawei.android.push.intent.RECEIVE" />
                <!-- 必须, 用于接收通知栏消息点击事件 此事件不需要开发者处理，只需注册就可以-->
                <action android:name="com.huawei.intent.action.PUSH_DELAY_NOTIFY" />
            </intent-filter>
        </receiver>
        <!-- ========================== 华为 push 相关配置  结束======================== -->

        <!-- ========================== vivo push 相关配置  开始======================== -->
        <!--Vivo Push开放平台中应用的appid 和api key-->
        <meta-data
            android:name="com.vivo.push.api_key"
            android:value="xxx" />
        <meta-data
            android:name="com.vivo.push.app_id"
            android:value="xxx" />
        <!-- ========================== vivo push 相关配置  结束======================== -->

        <!--  ========================== meizu push 相关配置  开始======================= -->
        <!-- push 应用定义消息 receiver 声明 -->
        <receiver android:name="com.tinet.push.platform.meizu.MZReceiver">
            <intent-filter>
                <!-- 接收 push 消息 -->
                <action android:name="com.meizu.flyme.push.intent.MESSAGE" />
                <!-- 接收 register 消息 -->
                <action android:name="com.meizu.flyme.push.intent.REGISTER.FEEDBACK" />
                <!-- 接收 unregister 消息-->
                <action android:name="com.meizu.flyme.push.intent.UNREGISTER.FEEDBACK" />
                <!-- 兼容低版本 Flyme3 推送服务配置 -->
                <action android:name="com.meizu.c2dm.intent.REGISTRATION" />
                <action android:name="com.meizu.c2dm.intent.RECEIVE" />

                <category android:name="${applicationId}" />
            </intent-filter>
        </receiver>
        <!-- ========================== meizu push 相关配置  结束======================== -->


```
**说明：以上配置需要在application标签内,且需要替换xxx为您应用对应的appid或appkey**
