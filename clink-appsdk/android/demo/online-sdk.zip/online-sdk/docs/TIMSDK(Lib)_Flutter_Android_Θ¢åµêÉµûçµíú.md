
# TIMSDK(lib)_Flutter_Android_集成文档

# 修订记录

| 版本 | 日期 | 修订人员 | 修订描述 |
| :------ | :------ | :------ | :------ |
| 1.0 | 6/28/2021 | 赵言 | 初始版本 |

## 目录
###### [搭建环境](#import)
###### [初始化](#init)
## <span id="import">搭建环境</span>
### 简介
> 此集成文档仅用于flutter集成Android timsdk lib 库 aar文件；
>
### 环境要求

name | 说明
---|---|---
Android SDK Build-tools | 21 及以上
Android SDK | Android API 19 及以上
JAVA |JDK 1.7 及以上
Gradle | 3.0 及以上版本

### 导入 SDK
#### aar 方式依赖
##### 导入 aar文件
1、打开flutter工程，打开android开发目录，点击编辑器右上角，点击 “open for Editing in Android Studio”即可打开Android项目

2、拷贝aar文件到Android 项目的app模块libs文件夹下，并在build.gradle 文件中配置如下：

```
api files('libs/timlib_1.0.0.25_sdk.aar')
```
##### 添加数据库
1、在Android项目的主目录 build.gradle 文件中配置如下

① buildscript -> dependencies 节点下：
```
classpath "io.realm:realm-gradle-plugin:6.0.2"
```

② allprojects -> repositories 节点下：
```
maven { url "https://jitpack.io" }
```
2、在Android项目的app模块 build.gradle 文件中配置如下

```
//说明：建议配置在“apply plugin: 'com.android.application'”节点之后
apply plugin: 'realm-android'
```

### 权限适配
开发者非必要动态申请以下权限

```
Manifest.permission.CAMERA,
Manifest.permission.RECORD_AUDIO,
Manifest.permission.WRITE_EXTERNAL_STORAGE,
Manifest.permission.READ_PHONE_STATE
```

##  <span id="init">初始化</span>
### 功能描述
TIMSDK 需要开发者在工程中调用下面方法来初始化 SDK。在 App 的整个生命周期中，开发者只需要将 SDK 初始化一次。

### 参数说明

参数    |	类型    |	必填    |	说明
---     |---        |---        |---
context |	Context |	是 |	上下文对象
tIMInitOption   |	TIMInitOption |是 |	初始化参数option

#### TIMInitOption 参数说明
参数    |	类型    |	必填    |	说明
---     |---        |---        |---
debug |	boolean |	否 |	是否开启debug模式
apiUrl   |	String |	否 |	默认sdk 请求url

### 代码示例
说明：只需要在继承Application类的onCreate初始化一次
> 注：由于flutter导入方式较为特殊，需要用户在java代码中创建一个类，继承FlutterApplication，并在清单文件中进行配置，然后在该类的onCreate方法下调用以下代码进行初始化操作；

```
        /**
         * TIMKit的初始化函数
         *
         * @param context  应用的上下文，一般为对应应用的ApplicationContext
         *
         */
        TIMInitOption initOption = new TIMInitOption();
        initOption.setDebug(false);
        TIMClient.init(this, initOption);
```
> 以上配置完即可正常在flutter项目中初始化timsdk；并使用sdk中其他服务，sdk其他服务需要开发者自行在java代码中创建渠道并实现与flutter的通信