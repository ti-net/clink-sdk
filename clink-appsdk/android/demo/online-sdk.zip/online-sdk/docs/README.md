#打包注意事项
1.在sdk项目中打包bmw选项
2.将俩个aar放到app项目中
3.清理一下app的module,将module压缩作为kit包
4.在sdk项目中去掉lib中的有关push的选项
5.打包lib的aar作为lib包
