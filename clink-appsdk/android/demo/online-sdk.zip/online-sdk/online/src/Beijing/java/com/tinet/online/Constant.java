package com.tinet.online;

import com.tinet.oslib.common.PlatformDefine;

/**
 * @author: liuzeren
 * @date: 2022/3/28
 */
public class Constant {

    public static final long enterpriseId = 8000002;
    public static final String accessId = "e2927165de3243b9989976b8d97ed425";
    public static final String accessSecret = "220D133193AF450696DEB735E1410764";

    public static final PlatformDefine define = PlatformDefine.Beijing;
}
