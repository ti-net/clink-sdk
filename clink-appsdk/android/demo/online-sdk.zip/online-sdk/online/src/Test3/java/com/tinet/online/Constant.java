package com.tinet.online;

import com.tinet.oslib.common.PlatformDefine;

/**
 * @author: liuzeren
 * @date: 2022/3/28
 */
public class Constant {

    public static final long enterpriseId = 8000581;
    public static final String accessId = "80a71b366026406f83b672a66bdd59ce";
    public static final String accessSecret = "B6F2A2125B2C476ABBA230F22B8B5D79";

    public static final PlatformDefine define = PlatformDefine.Test3;
}
