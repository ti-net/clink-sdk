//com.tinet.online.test目录下面的类不需要关心，与SDK接入无关

