package com.tinet.online;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.tinet.oslib.OnlineServiceClient;
import com.tinet.oslib.listener.OnlineConnectResultCallback;
import com.tinet.oslib.listener.OnlineDisconnectListener;

/**
 * @ProjectName: TIMSDK
 * @ClassName: LoginActivity
 * @Author: liuzr
 * @CreateDate: 2021-08-26 14:35
 * @Description:
 */
public class LoginActivity extends AppCompatActivity {

    private EditText etId,etNickname,etHeader;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.aty_login);

        etId = findViewById(R.id.etId);
        etNickname = findViewById(R.id.etNickname);
        etHeader = findViewById(R.id.etHeader);

        findViewById(R.id.btnLogin).setOnClickListener(v -> {
            final String id = etId.getText().toString();
            final String nickname = TextUtils.isEmpty(etNickname.getText().toString())?"帅哥":etNickname.getText().toString();
            final String headerUrl = TextUtils.isEmpty(etHeader.getText().toString()) ? "http://thirdwx.qlogo.cn/mmopen/GuNoXpnSSvrcI6Gt9qcoicS7YIvcSFaibX2GFTbic6gX0gzPWgMmViccoib6jX59KAoEhcV1CceGg4kjwhr1RkLmhoLgN3O5mfiak7/132":etHeader.getText().toString();


            //同一用户不会导致重连
            OnlineServiceClient.connect(id,nickname,headerUrl,new OnlineConnectResultCallback(){

                @Override
                public void onSuccess() {
                    //
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                }

                @Override
                public void onError(int errorCode, String errorDesc) {

                }
            });
        });

        findViewById(R.id.btnLoginOut).setOnClickListener(v -> OnlineServiceClient.disConnect(false, new OnlineDisconnectListener() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onFailure(Exception e) {

            }
        }));

        findViewById(R.id.btnLoginOutPush).setOnClickListener(v -> OnlineServiceClient.disConnect(true,null));
    }
}
