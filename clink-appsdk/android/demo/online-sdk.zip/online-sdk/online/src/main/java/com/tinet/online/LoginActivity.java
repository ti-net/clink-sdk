package com.tinet.online;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.tinet.oskit.widget.web.TinetWebView;
import com.tinet.oslib.OnlineServiceClient;
import com.tinet.oslib.listener.OnlineConnectResultCallback;
import com.tinet.oslib.listener.OnlineDisconnectListener;

import java.util.HashMap;
import java.util.Map;

/**
 * @ProjectName: TIMSDK
 * @ClassName: LoginActivity
 * @Author: liuzr
 * @CreateDate: 2021-08-26 14:35
 * @Description:
 */
public class LoginActivity extends AppCompatActivity {

    private EditText etId,etNickname,etHeader,etPhone;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.aty_login);
        etId = findViewById(R.id.etId);
        etNickname = findViewById(R.id.etNickname);
        etHeader = findViewById(R.id.etHeader);
        etPhone = findViewById(R.id.etPhone);

        findViewById(R.id.btnLogin).setOnClickListener(v -> {
            final String id = etId.getText().toString();
            final String nickname = TextUtils.isEmpty(etNickname.getText().toString())?"帅哥":etNickname.getText().toString();
            final String headerUrl = "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg0.baidu.com%2Fit%2Fu%3D3756612858%2C3402326085%26fm%3D253%26app%3D120%26f%3DJPEG%3Fw%3D800%26h%3D800&refer=http%3A%2F%2Fimg0.baidu.com&app=2002&size=w300&q=a80&n=0&g=0n&fmt=jpeg?sec=1645248623&t=986bb2e68ec43d9e8c4e9433d3990e91";

            Map<String,Object> extraInfo = new HashMap<>();
            extraInfo.put("tinetAddress","江苏南京");
            extraInfo.put("tinetSex","男");
            extraInfo.put("tinetType","用户端（安卓）");
            extraInfo.put("tinetAge",36);
            extraInfo.put("测试","测试数据");

            android.util.Log.d("liuzr","进入客服,"+System.currentTimeMillis());

            String phone = etPhone.getText().toString();
            if(TextUtils.isEmpty(phone)){
                phone = "13851415555";
            }

            //同一用户不会导致重连
            OnlineServiceClient.connect(id,nickname,headerUrl,phone,extraInfo,new OnlineConnectResultCallback(){

                @Override
                public void onSuccess() {
                    //
                    android.util.Log.d("liuzr","进入聊天,"+System.currentTimeMillis());
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                }

                @Override
                public void onError(int errorCode, String errorDesc) {

                }
            });
        });

        findViewById(R.id.btnLoginOut).setOnClickListener(v -> OnlineServiceClient.disConnect(false, new OnlineDisconnectListener() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onFailure(Exception e) {

            }
        }));

        findViewById(R.id.btnLoginOutPush)
                .setOnClickListener(v ->
        OnlineServiceClient.disConnect(true,null));
    }

}
