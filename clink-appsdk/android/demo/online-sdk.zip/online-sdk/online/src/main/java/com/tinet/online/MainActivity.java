package com.tinet.online;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.tinet.oskit.TOSClientKit;
import com.tinet.oslib.OnlineServiceClient;
import com.tinet.oslib.listener.SessionInfoResult;
import com.tinet.oslib.manager.OnlineMessageManager;
import com.tinet.oslib.model.bean.SessionInfo;
import com.tinet.threepart.tools.TUIUtils;
import com.tinet.timclientlib.utils.TLogUtils;

public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ChatFragment chatFragment = new ChatFragment();
        chatFragment.setArguments(getIntent().getExtras());
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.container, chatFragment);
        transaction.commitAllowingStateLoss();

        updateStatus(OnlineMessageManager.getCurrentOnlineStatus());

        //在线状态变化事件
        TOSClientKit
            .setOnlineStatusListener(new OnlineMessageManager.OnlineStatusListener() {
                @Override
                public void onStatusChanged(int status) {
                    updateStatus(status);
                }
            });

        OnlineServiceClient.getCurrentSessionInfo(new SessionInfoResult() {
            @Override
            public void sessionInfo(SessionInfo sessionInfo) {
                TUIUtils.postTaskSafely(new Runnable() {
                    @Override
                    public void run() {
                        toolbar.setSubtitle(sessionInfo.getMainUniqueId());
                    }
                });
            }
        });
    }

    private void updateStatus(int status){
        TUIUtils.postTaskSafely(new Runnable() {
            @Override
            public void run() {
                toolbar.setTitle(
                    "在线客服(" + (status == OnlineMessageManager.STATUS_ROBOT ? "机器人"
                        : (status == OnlineMessageManager.STATUS_ONLINE ? "人工座席"
                            : "--"))
                        + ")");
            }
        });
    }
}