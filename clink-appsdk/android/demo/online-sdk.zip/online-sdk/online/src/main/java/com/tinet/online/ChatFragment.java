package com.tinet.online;

import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.tinet.oskit.fragment.SessionFragment;
import com.tinet.oskit.listener.FuncListener;
import com.tinet.oskit.listener.SessionClickListener;
import com.tinet.oskit.listener.impl.FuncListenerImpl;
import com.tinet.oskit.listener.impl.SessionClickListenerImpl;
import com.tinet.oskit.model.Function;

import java.util.ArrayList;
import java.util.List;

/**
 * @ProjectName: TIMSDK
 * @ClassName: ChatFragment
 * @Author: liuzr
 * @CreateDate: 2021-10-11 19:11
 * @Description:
 */
public class ChatFragment extends SessionFragment {

    @Override
    protected SessionClickListener getListener() {
        return new SessionClickListenerImpl(this){
            @Override
            public void onLinkClick(String url) {
//                super.onLinkClick(url);
                //TODO 自定义超链接事件
                Toast.makeText(requireContext(),"超链接地址："+url,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void videoPlay(String url) {
                super.videoPlay(url);
                //TODO 自定义视频播放，如果需要自己实现视频播放，则需要屏蔽super.videoPlay(url);父类的实现方式
                Toast.makeText(requireContext(),"视频播放地址："+url,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onImageMessageClick(ArrayList<String> messages, int index) {
                super.onImageMessageClick(messages, index);

                //TODO 自定义图片查看器
            }
        };
    }

    @Override
    public void funcList(List<Function> funcs) {
        super.funcList(funcs);


        /**
         //TODO 底部功能栏自定义
         List<Function> fucs = new ArrayList<>();
         fucs.add(new Function(Function.TYPE_SYSTEM,Function.SEND_IMAGE));
         fucs.add(new Function(Function.TYPE_SYSTEM,Function.SEND_VIDEO));
         fucs.add(new Function(Function.TYPE_SYSTEM,Function.SEND_FILE));
         fucs.add(new Function(Function.TYPE_SYSTEM,Function.TO_ONLINE));

         //中间添加一个功能
         fucs.add(new Function(ContextCompat.getDrawable(requireContext(),R.drawable.robot_default_head),"机器人"));

         fucs.add(new Function(Function.TYPE_SYSTEM,Function.CHAT_OVER));

         super.funcList(fucs);
         */
    }

    @Override
    protected FuncListener getFuncListener() {
        //TODO 自定义底部功能栏

        return new FuncListenerImpl(this){
            @Override
            public void onFuncClick(Function func) {
                super.onFuncClick(func);
                if("机器人".equals(func.getTitle())){
                    getPresent().sendText("发送文本：机器人");
                }
            }
        };
    }
}
