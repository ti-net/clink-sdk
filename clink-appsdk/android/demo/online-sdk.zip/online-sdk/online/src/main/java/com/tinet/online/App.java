package com.tinet.online;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.multidex.MultiDexApplication;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.tinet.oskit.listener.TImageLoaderListener;
import com.tinet.oskit.OnlineKitManager;
import com.tinet.oskit.listener.TImageLoader;
import com.tinet.oslib.manager.OnlineMessageManager;
import com.tinet.timclientlib.utils.TLogUtils;

/**
 * @ProjectName: TIMSDK
 * @ClassName: App
 * @Author: liuzr
 * @CreateDate: 2021-08-23 14:42
 * @Description:
 */
public class App extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();

        initOnlineService();

        //获取当前在线状态
        //OnlineMessageManager.STATUS_OUTLINE  不在线（会话结束）
        //OnlineMessageManager.STATUS_ROBOT     机器人
        //OnlineMessageManager.STATUS_ONLINE    人工座席
        int currentOnlineStatus = OnlineMessageManager.getCurrentOnlineStatus();

        //在线状态变化事件
        OnlineMessageManager.setOnlineStatusListener(new OnlineMessageManager.OnlineStatusListener() {
            @Override
            public void onStatusChanged(int status) {
                TLogUtils.d("当前状态：" + status);
            }
        });
    }

    private void initOnlineService(){
        OnlineKitManager.init(this,
                Constant.accessId ,
                Constant.accessSecret,
                Constant.enterpriseId,
                Constant.define, new TImageLoader() {
            @Override
            public void loadImage(ImageView imageView, Object uri) {
                //以glide为示例
                Glide.with(imageView.getContext())
                        .load(uri)
                        .error(R.drawable.ti_ic_load_default_image)
                        .placeholder(R.drawable.ti_ic_load_default_image)
                        .into(imageView);
            }

            @Override
            public void loadImage(ImageView imageView, Object uri, int placeholderImg, int errorImg) {
                Glide.with(imageView.getContext())
                        .load(uri)
                        .override(CustomTarget.SIZE_ORIGINAL,CustomTarget.SIZE_ORIGINAL)
                        .error(errorImg)
                        .placeholder(placeholderImg)
                        .into(imageView);
            }

            @Override
            public void loadImage(ImageView imageView, Object uri, int originalWidth, int originalHeight, TImageLoaderListener listener) {
                Glide.with(imageView.getContext()).load(uri)
                        .override(originalWidth,originalHeight)
                        .listener(new ImageRequestListener(listener))
                        .error(R.drawable.ti_ic_load_default_image)
                        .placeholder(R.drawable.ti_ic_load_default_image).into(imageView);
            }

            @Override
            public void loadImage(Context context,Object uri,int originalWidth, int originalHeight,TImageLoaderListener listener){
                Glide.with(context).load(uri).override(originalWidth,originalHeight).into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        if(null != listener){
                            listener.onResourceReady(resource);
                        }
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                        if(null != listener){
                            listener.onLoadFailed();
                        }
                    }
                });
            }
        },BuildConfig.DEBUG);
    }

    class ImageRequestListener implements RequestListener<Drawable> {

        private TImageLoaderListener listener;

        public ImageRequestListener(TImageLoaderListener listener){
            this.listener = listener;
        }

        @Override
        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
            if(null != listener){
                listener.onLoadFailed();
            }

            return false;
        }

        @Override
        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
            if(null != listener){
                listener.onResourceReady(resource);
            }
            return false;
        }
    }
}
