package com.tinet.online;

import android.app.Application;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.tinet.oskit.listener.TImageLoaderListener;
import com.tinet.oskit.OnlineKitManager;
import com.tinet.oskit.listener.TImageLoader;
import com.tinet.oslib.OnlineServiceClient;
import com.tinet.oslib.config.OnlineInitOption;
import com.tinet.oslib.listener.OnlineConnectStatusListener;
import com.tinet.push.PushManager;
import com.tinet.push.TIMPushManager;
import com.tinet.push.pushconfig.PushConfig;
import com.tinet.timclientlib.callback.TOperationCallback;
import com.tinet.timclientlib.manager.TIMBaseManager;

/**
 * @ProjectName: TIMSDK
 * @ClassName: App
 * @Author: liuzr
 * @CreateDate: 2021-08-23 14:42
 * @Description:
 */
public class App extends Application {

    public static final String XIAOMI_APP_ID = "2882303761518438316";

    public static final String XIAOMI_APP_key = "5591843830316";

    public static final String HMS_APP_ID = "2882303761518438316";

    public static final String OPPO_APP_ID = "30307346";

    public static final String OPPO_APP_key = "33bc631364944597bea3f07d8e206714";

    public static final String OPPO_APP_SECRET = "c54ecd6304dc43fa802a3e617b434284";

    public static final String VIVO_APP_ID = "103910811";

    public static final String VIVO_APP_key = "bb47d47c7ea95ab1020330db8d156580";

    public static final String MEIZU_APP_ID = "132029";

    public static final String MEIZU_APP_key = "3af2ef31284c4734b38c66d243c5a2f2";

    public static final String accessId = "9999d7a14daa4295a568bb0854fa6666";
    public static final String accessSecret = "9999D7A14DAA4295A568BB0854FA6666";
    public static final long enterpriseId = 8000581;

    @Override
    public void onCreate() {
        super.onCreate();

        initPush();
        initOnlineService();
    }

    /**
     * online 推送初始化
     */
    private void initPush(){
        OnlineServiceClient.addOnlineConntectStatusListener(new OnlineConnectStatusListener() {
            @Override
            public void onConnecting() {

            }

            @Override
            public void onConnected() {
                PushConfig config = new PushConfig.Builder()
                        .setMiPush(App.XIAOMI_APP_ID, App.XIAOMI_APP_key)//小米push配置
                        .setHWPush(true)//华为push配置
                        .setOppoPush(App.OPPO_APP_key, App.OPPO_APP_SECRET)//oppo push配置
                        .setVivoPush(true)//vivo push配置
                        .setMeiZuPush(App.MEIZU_APP_ID, App.MEIZU_APP_key)//meizu push配置
                        .build();

                TIMPushManager.init(App.this, OnlineServiceClient.getCurrentUserInfo().getTokenInfo().getAppId(), config, (pushType, token) -> TIMBaseManager.getInstance().updateDeviceToken(token, new TOperationCallback() {
                    @Override
                    public void onSuccess() {
                    }

                    @Override
                    public void onError(int errorCode, String errorDesc) {
                    }
                }));
            }

            @Override
            public void onDisconnected() {
                //TODO 连接断开
            }

            @Override
            public void onReConnecting() {
                //TODO 正在进行重连接
            }

            @Override
            public void onReconnected() {
                //TODO 重连接成功
            }

            @Override
            public void onKickOut() {
                //TODO 被踢出
            }
        });
    }

    private void initOnlineService(){
        OnlineInitOption option = new OnlineInitOption();
        option.setAccessId(accessId);
        option.setAccessSecret(accessSecret);
        option.setEnterpriseId(enterpriseId);
        option.setApiUrl("https://octopus-api-1.vlink.cn/api/sdk/v1");
        option.setOnlineUrl("http://chat-app-bj-test3.clink.cn");
        option.setDebug(BuildConfig.DEBUG);

        OnlineKitManager.init(this, option, new TImageLoader() {
            @Override
            public void loadImage(ImageView imageView, Object uri) {
                //以glide为示例
                Glide.with(imageView.getContext()).load(uri).error(R.drawable.ti_ic_load_default_image).override(CustomTarget.SIZE_ORIGINAL,CustomTarget.SIZE_ORIGINAL).placeholder(R.drawable.ti_ic_load_default_image).into(imageView);
            }

            @Override
            public void loadImage(ImageView imageView, Object uri, int placeholderImg, int errorImg) {
                Glide.with(imageView.getContext()).load(uri).override(CustomTarget.SIZE_ORIGINAL,CustomTarget.SIZE_ORIGINAL).error(errorImg).placeholder(placeholderImg).into(imageView);
            }

            @Override
            public void loadImage(ImageView imageView, Object uri, int originalWidth, int originalHeight, TImageLoaderListener listener) {
                Glide.with(imageView.getContext()).load(uri)
                        .override(originalWidth,originalHeight)
                        .listener(new ImageRequestListener(listener))
                        .error(R.drawable.ti_ic_load_default_image)
                        .placeholder(R.drawable.ti_ic_load_default_image).into(imageView);
            }

            @Override
            public void loadImage(Context context,Object uri,int originalWidth, int originalHeight,TImageLoaderListener listener){
                Glide.with(context).load(uri).override(originalWidth,originalHeight).into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        if(null != listener){
                            listener.onResourceReady(resource);
                        }
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                        if(null != listener){
                            listener.onLoadFailed();
                        }
                    }
                });
            }
        });
    }

    class ImageRequestListener implements RequestListener<Drawable> {

        private TImageLoaderListener listener;

        public ImageRequestListener(TImageLoaderListener listener){
            this.listener = listener;
        }

        @Override
        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
            if(null != listener){
                listener.onLoadFailed();
            }

            return false;
        }

        @Override
        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
            if(null != listener){
                listener.onResourceReady(resource);
            }
            return false;
        }
    }
}
