package com.tinet.online;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.multidex.MultiDexApplication;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.tencent.bugly.crashreport.CrashReport;
import com.tinet.online.test.PlantformInfo;
import com.tinet.online.test.PlantformUtil;
import com.tinet.oskit.listener.TImageLoaderListener;
import com.tinet.oskit.TOSClientKit;
import com.tinet.oskit.listener.TImageLoader;
import com.tinet.oslib.common.PlatformDefine;
import com.tinet.oslib.config.TOSInitOption;
import com.tinet.oslib.listener.OnlineMessageListener;
import com.tinet.oslib.manager.OnlineMessageManager;
import com.tinet.oslib.model.message.OnlineMessage;
import com.tinet.timclientlib.manager.TIMBaseManager;
import com.tinet.timclientlib.utils.TLogUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * @ProjectName: TIMSDK
 * @ClassName: App
 * @Author: liuzr
 * @CreateDate: 2021-08-23 14:42
 * @Description:
 */
public class App extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();

        CrashReport.initCrashReport(getApplicationContext(), "ebb6b84a11", false);

        initOnlineService();

        //获取当前在线状态
        //OnlineMessageManager.STATUS_OUTLINE  不在线（会话结束）
        //OnlineMessageManager.STATUS_ROBOT     机器人
        //OnlineMessageManager.STATUS_ONLINE    人工座席
        int currentOnlineStatus = OnlineMessageManager.getCurrentOnlineStatus();

        TOSClientKit.addOnlineMessageListener(new OnlineMessageListener() {
            @Override
            public void onMessage(OnlineMessage message) {
                TLogUtils.d("收到新消息，消息类型：" + message.getOnlineContent().getClass().getName() + ",消息内容" + message.getOnlineContent().getContent());
            }
        });
    }

    private void initOnlineService() {
        //PlantformInfo与接入无关，接入时直接申请：accessId，accessSecret，enterpriseId填入即可
        PlantformInfo info = PlantformUtil.getPlantform(this);
        String accessId = info == null ? Constant.accessId : info.getAccessId();
        String accessSecret = info == null ? Constant.accessSecret : info.getAccessSecret();
        long enterpriseId = info == null ? Constant.enterpriseId : info.getEnterpriseId();
        PlatformDefine define = info == null ? Constant.define : info.getPlatform();

        TLogUtils.d("enterpriseId=" + enterpriseId + "\naccessId=" + accessId + "\naccessSecret=" + accessSecret + "\ndefine=" + define);

        TOSInitOption tOSInitOption = new TOSInitOption();
        tOSInitOption.setAccessId(accessId); //
        tOSInitOption.setAccessSecret(accessSecret);
        tOSInitOption.setEnterpriseId(enterpriseId);
        tOSInitOption.setApiUrl(define.getApiUrl());
        tOSInitOption.setOnlineUrl(define.getOnlineUrl());
        tOSInitOption.setDebug(BuildConfig.DEBUG);

        // : 2022/6/23  此处添加环境标识参数等可配参数
        if (info != null)
            if ("Kt".equals(info.getType())) {
                Map<String, Object> headers = new HashMap<>();
                headers.put("deBugEnv", "ktTest");
                tOSInitOption.setAdvanceParams(headers);
            }

        TOSClientKit.initSDK(this, tOSInitOption, new TImageLoader() {
            @Override
            public void loadImage(ImageView imageView, Object uri) {
                //以glide为示例
                Glide.with(imageView.getContext())
                        .load(uri)
                        .error(R.drawable.ti_ic_load_default_image)
                        .placeholder(R.drawable.ti_ic_load_default_image)
                        .into(imageView);
            }

            @Override
            public void loadImage(ImageView imageView, Object uri, int placeholderImg, int errorImg) {
                Glide.with(imageView.getContext())
                        .load(uri)
                        .override(CustomTarget.SIZE_ORIGINAL, CustomTarget.SIZE_ORIGINAL)
                        .error(errorImg)
                        .placeholder(placeholderImg)
                        .into(imageView);
            }

            @Override
            public void loadImage(ImageView imageView, Object uri, int originalWidth, int originalHeight, TImageLoaderListener listener) {
                Glide.with(imageView.getContext()).load(uri)
                        .override(originalWidth, originalHeight)
                        .listener(new ImageRequestListener(listener))
                        .error(R.drawable.ti_ic_load_default_image)
                        .placeholder(R.drawable.ti_ic_load_default_image).into(imageView);

            }

            @Override
            public void loadImage(Context context, Object uri, int originalWidth, int originalHeight, TImageLoaderListener listener) {
                Glide.with(context).load(uri).override(originalWidth, originalHeight).into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        if (null != listener) {
                            listener.onResourceReady(resource);
                        }
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                        if (null != listener) {
                            listener.onLoadFailed();
                        }
                    }
                });
            }
        });

        CrashReport.initCrashReport(getApplicationContext(), "ebb6b84a11", false);

    }

    class ImageRequestListener implements RequestListener<Drawable> {

        private TImageLoaderListener listener;

        public ImageRequestListener(TImageLoaderListener listener) {
            this.listener = listener;
        }

        @Override
        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
            if (null != listener) {
                listener.onLoadFailed();
            }

            return false;
        }

        @Override
        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
            if (null != listener) {
                listener.onResourceReady(resource);
            }
            return false;
        }
    }
}
