package com.tinet.online;

import com.tinet.oslib.common.PlatformDefine;

/**
 * @author: liuzeren
 * @date: 2022/3/28
 */
public class Constant {

    public static final long enterpriseId = 8003846;
    public static final String accessId = "f8f7d2be61ce4b8ba272b35647ac1eb2";
    public static final String accessSecret = "D5B70DD63C4848B6824C0233D2FC201F";

    public static final PlatformDefine define = PlatformDefine.Shanghai;
}
