//
//  customTableViewCell.h
//  TOSClientKitDemo
//
//  Created by 李成 on 2023/6/8.
//  Copyright © 2023 YanBo. All rights reserved.
//

#import "TOSChatCustomBaseTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface customTableViewCell : TOSChatCustomBaseTableViewCell

@end

NS_ASSUME_NONNULL_END
