//
//  CustomRefreshHeader.h
//  TOSClientKitDemo
//
//  Created by 李成 on 2023/6/19.
//  Copyright © 2023 YanBo. All rights reserved.
//

#import <TOSClientKit/TOSClientKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomRefreshHeader : TIMRefreshHeader

@end

NS_ASSUME_NONNULL_END
