//
//  SWTextAttachment.h
//  SWEmojiKeyboard
//
//  Created by zhoushaowen on 2018/1/15.
//  Copyright © 2018年 zhoushaowen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SWTextAttachment : NSTextAttachment

@property (nonatomic,copy) NSString *chs;

@end
