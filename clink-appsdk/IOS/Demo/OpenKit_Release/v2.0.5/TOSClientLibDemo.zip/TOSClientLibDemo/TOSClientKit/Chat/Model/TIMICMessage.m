//
//  ICMessage.m
//  XZ_WeChat
//
//  Created by 赵言 on 16/3/10.
//  Copyright © 2016年 gxz All rights reserved.
//

#import "TIMICMessage.h"

@implementation TIMICMessage



@end
