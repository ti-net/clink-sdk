//
//  ICEmotionListView.h
//  XZ_WeChat
//
//  Created by 赵言 on 16/4/6.
//  Copyright © 2016年 gxz All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ICEmotionListView : UIView

@property (nonatomic, strong) NSArray *emotions;
@property (nonatomic, strong) NSArray *gifemotions;

@end
