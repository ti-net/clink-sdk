//
//  TOSKitExtendBoardItemModel.m
//  TOSClientKit
//
//  Created by 言 on 2022/7/13.
//  Copyright © 2022 YanBo. All rights reserved.
//

#import "TOSKitExtendBoardItemModel.h"

@implementation TOSKitExtendBoardItemModel

@end
