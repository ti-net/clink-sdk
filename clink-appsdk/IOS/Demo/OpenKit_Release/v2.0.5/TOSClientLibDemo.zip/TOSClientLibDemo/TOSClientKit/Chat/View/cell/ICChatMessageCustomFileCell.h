//
//  ICChatMessageCustomFileCell.h
//  XZ_WeChat
//
//  Created by 赵言 on 16/7/20.
//  Copyright © 2016年 gxz All rights reserved.
//

#import "ICChatMessageBaseCell.h"

@interface ICChatMessageCustomFileCell : ICChatMessageBaseCell


@end
