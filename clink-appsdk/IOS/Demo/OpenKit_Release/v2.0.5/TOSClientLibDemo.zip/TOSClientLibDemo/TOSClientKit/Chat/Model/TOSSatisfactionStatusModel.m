//
//  TOSSatisfactionStatusModel.m
//  TOSClientKit
//
//  Created by 言 on 2022/8/26.
//  Copyright © 2022 YanBo. All rights reserved.
//

#import "TOSSatisfactionStatusModel.h"

@implementation TOSSatisfactionStatusModel

@end
