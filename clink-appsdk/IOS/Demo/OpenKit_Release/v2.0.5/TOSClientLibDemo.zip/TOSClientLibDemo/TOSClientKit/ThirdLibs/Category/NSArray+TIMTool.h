//
//  NSArray+TIMTool.h
//  TIMClientKit
//
//  Created by 赵言 on 2020/12/8.
//  Copyright © 2020 YanBo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSArray (TIMTool)

- (id)by_ObjectAtIndex:(NSUInteger)index;

@end

NS_ASSUME_NONNULL_END
