//
//  MYHTZGifPhotoPreviewController.h
//  MYHTZImagePickerController
//
//  Created by ttouch on 2016/12/13.
//  Copyright © 2016年 谭真. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MYHTZAssetModel;
@interface MYHTZGifPhotoPreviewController : UIViewController

@property (nonatomic, strong) MYHTZAssetModel *model;

@end
