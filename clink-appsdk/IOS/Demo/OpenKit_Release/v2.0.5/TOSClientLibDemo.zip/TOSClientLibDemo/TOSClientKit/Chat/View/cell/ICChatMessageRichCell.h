//
//  ICChatMessageRichCell.h
//  TOSClientKit
//
//  Created by 言 on 2022/6/14.
//  Copyright © 2022 YanBo. All rights reserved.
//

#import "ICChatMessageBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ICChatMessageRichCell : ICChatMessageBaseCell



@end

NS_ASSUME_NONNULL_END
