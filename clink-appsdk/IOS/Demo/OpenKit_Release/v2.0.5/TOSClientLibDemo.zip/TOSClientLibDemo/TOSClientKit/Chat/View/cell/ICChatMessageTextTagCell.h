//
//  ICChatMessageTextTagCell.h
//  TOSClientKit
//
//  Created by 言 on 2022/9/8.
//  Copyright © 2022 YanBo. All rights reserved.
//

#import "ICChatMessageBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ICChatMessageTextTagCell : ICChatMessageBaseCell

@end

NS_ASSUME_NONNULL_END
