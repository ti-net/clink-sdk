//
//  ICChatMessageTextCell.h
//  XZ_WeChat
//
//  Created by 赵言 on 16/3/13.
//  Copyright © 2016年 gxz All rights reserved.
//

#import "ICChatMessageBaseCell.h"
#import "YYLabel.h"

@interface ICChatMessageTextCell : ICChatMessageBaseCell

@property (nonatomic, strong) YYLabel *chatLabel;



@end

