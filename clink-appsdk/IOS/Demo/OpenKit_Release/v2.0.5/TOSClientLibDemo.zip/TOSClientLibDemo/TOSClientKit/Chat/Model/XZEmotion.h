//
//  XZEmotion.h
//  XZ_WeChat
//
//  Created by 赵言 on 16/9/27.
//  Copyright © 2016年 gxz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XZEmotion : NSObject

@property (nonatomic, copy) NSString *face_name;

@property (nonatomic, copy) NSString *face_id;

@property (nonatomic, copy) NSString *code;

@property (nonatomic, copy) NSString *type;

@end
