//
//  ICVoiceHud.h
//  XZ_WeChat
//
//  Created by 赵言 on 16/5/18.
//  Copyright © 2016年 gxz All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICVoiceHud : UIImageView


@property (nonatomic, assign) CGFloat progress;



@end
