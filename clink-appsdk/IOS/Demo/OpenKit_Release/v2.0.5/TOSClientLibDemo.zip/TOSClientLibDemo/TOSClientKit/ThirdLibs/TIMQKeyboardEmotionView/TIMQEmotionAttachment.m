//
//  TIMQEmotionAttachment.m
//  QKeyboardEmotionView
//
//  Created by 侯力 on 2024/3/19.
//

#import "TIMQEmotionAttachment.h"

@implementation TIMQEmotionAttachment

@end
