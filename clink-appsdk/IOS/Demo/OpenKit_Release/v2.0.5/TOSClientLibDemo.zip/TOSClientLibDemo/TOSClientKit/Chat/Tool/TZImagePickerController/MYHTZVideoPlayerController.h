//
//  MYHTZVideoPlayerController.h
//  MYHTZImagePickerController
//
//  Created by 谭真 on 16/1/5.
//  Copyright © 2016年 谭真. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MYHTZAssetModel;
@interface MYHTZVideoPlayerController : UIViewController

@property (nonatomic, strong) MYHTZAssetModel *model;

@end

