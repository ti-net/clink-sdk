//
//  ICEmotionButton.h
//  XZ_WeChat
//
//  Created by 赵言 on 16/4/6.
//  Copyright © 2016年 gxz All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XZEmotion.h"

@interface ICEmotionButton : UIButton

@property (nonatomic, strong) XZEmotion *emotion;

@end
