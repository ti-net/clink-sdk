//
//  ICChatMessageCustomDeafultCell.h
//  TIMClientKit
//
//  Created by YanBo on 2020/8/27.
//  Copyright © 2020 YanBo. All rights reserved.
//

#import "ICChatMessageBaseCell.h"
#import "TIMLabel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ICChatMessageCustomDeafultCell : ICChatMessageBaseCell

@end

NS_ASSUME_NONNULL_END
