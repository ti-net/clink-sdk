//
//  ICChatMessageLogisticsCardCell.h
//  TOSClientKit
//
//  Created by 言 on 2023/1/4.
//  Copyright © 2023 YanBo. All rights reserved.
//

#import "ICChatMessageBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ICChatMessageLogisticsCardCell : ICChatMessageBaseCell

@end

NS_ASSUME_NONNULL_END
