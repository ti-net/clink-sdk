//
//  ICChatMessageSatisfactionPopupCell.h
//  TOSClientKit
//
//  Created by 言 on 2023/10/8.
//  Copyright © 2023 YanBo. All rights reserved.
//

#import "ICChatMessageBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ICChatMessageSatisfactionPopupCell : ICChatMessageBaseCell

@end

NS_ASSUME_NONNULL_END
