//
//  TIMMessageModel.m
//  XZ_WeChat
//
//  Created by 赵言 on 16/3/12.
//  Copyright © 2016年 gxz All rights reserved.
//

#import "TIMMessageModel.h"

@implementation TIMMessageModel

@end
