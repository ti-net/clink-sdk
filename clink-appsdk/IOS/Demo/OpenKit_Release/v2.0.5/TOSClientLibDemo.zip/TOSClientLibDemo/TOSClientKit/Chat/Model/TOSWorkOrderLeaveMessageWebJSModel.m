//
//  TOSWorkOrderLeaveMessageWebJSModel.m
//  TOSClientKit
//
//  Created by 言 on 2024/7/11.
//  Copyright © 2024 YanBo. All rights reserved.
//

#import "TOSWorkOrderLeaveMessageWebJSModel.h"

@implementation TOSWorkOrderLeaveMessageWebJSDataModel

@end

@implementation TOSWorkOrderLeaveMessageWebJSModel

@end
