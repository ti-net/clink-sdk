//
//  ICChatMessageCommodityCardCell.h
//  TIMClientKit
//
//  Created by 赵言 on 2022/5/23.
//  Copyright © 2022 YanBo. All rights reserved.
//

#import "ICChatMessageBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ICChatMessageCommodityCardCell : ICChatMessageBaseCell

@end

NS_ASSUME_NONNULL_END
