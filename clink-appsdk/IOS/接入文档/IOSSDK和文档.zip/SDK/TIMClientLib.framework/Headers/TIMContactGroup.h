//
//  TIMContactGroup.h
//  TIMClientLib
//
//  Created by YanBo on 2020/4/17.
//  Copyright © 2020 YanBo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TIMContactGroup : NSObject

@end

NS_ASSUME_NONNULL_END
